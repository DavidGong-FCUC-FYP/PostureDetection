package com.posturedetection.android.data

enum class Camera {
    FRONT,
    BACK
}
