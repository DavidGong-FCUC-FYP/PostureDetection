package com.bigkoo.pickerview.listener;

/**
 * Created by xiaosong on 2018/3/20.
 */

public interface OnOptionsSelectChangeListener {

    void onOptionsSelectChanged(int options1, int options2, int options3);

}
